package com.loan.mangement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.loan.mangement.entity.ApplicantDetailsDAO;

public interface IApplicationDetailsRepo extends JpaRepository<ApplicantDetailsDAO, Integer> {

}
