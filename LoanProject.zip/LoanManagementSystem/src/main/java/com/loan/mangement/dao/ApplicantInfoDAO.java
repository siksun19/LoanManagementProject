package com.loan.mangement.dao;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
//@Table
@Data
public class ApplicantInfoDAO {

	
	@Id
	private String aplcntAdharNumber;
		
	private String aplcntName;
		
	private String aplcntphNumber;
		
	private String aplcntgender;
	
	private String fatherName;
	
	private String motherName;
	
	private Date aplcntdob;
	
	private String gntrName;
	
	private String gntrPhNumber;
	
	private String gntrgender;

	private Date gntrdob;
	
	private String gntrAdharNumber;
	
	private String occupation;
	
	private String annualIncome;
	
	@OneToOne(cascade = CascadeType.ALL)
	private EducationalDetailsDAO educationaldao;
	
	
}
