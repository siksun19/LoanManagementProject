package com.loan.mangement.service;

import com.loan.mangement.dto.LoanManagementRequestDTO;

public interface IEducationalDetailsService {
	String saveEduacationalDetails(LoanManagementRequestDTO loanreqDTO);

}
