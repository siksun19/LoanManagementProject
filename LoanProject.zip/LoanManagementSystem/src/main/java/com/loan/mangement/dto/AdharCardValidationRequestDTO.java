package com.loan.mangement.dto;



public class AdharCardValidationRequestDTO {
	
	private String adharNumber;

	public final String getAdharNumber() {
		return adharNumber;
	}

	public final void setAdharNumber(String adharNumber) {
		this.adharNumber = adharNumber;
	}

	public AdharCardValidationRequestDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
