package com.loan.mangement.serviceimpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loan.mangement.dao.ApplicantInfoDAO;
import com.loan.mangement.dao.EducationalDetailsDAO;
import com.loan.mangement.dto.LoanManagementRequestDTO;
import com.loan.mangement.repo.IApplicantInfoRepo;
import com.loan.mangement.repo.IEducationalDetailsRepo;
import com.loan.mangement.service.IApplicantsService;
import com.loan.mangement.service.IEducationalDetailsService;

import jakarta.transaction.Transactional;

@Service
public class ApplicantServiceImpl implements IApplicantsService,IEducationalDetailsService{
	@Autowired
	IApplicantInfoRepo applicantinfo;
	@Autowired
	IEducationalDetailsRepo educationaldetailrepo;
	
	EducationalDetailsDAO educationaldetaildao;
	
	
	//@Transactional
	public String saveApplicantInfo(LoanManagementRequestDTO loanreqDTO) {
		ApplicantInfoDAO applicantDAO=new ApplicantInfoDAO();

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);

		String dateInString1 =loanreqDTO.getAplcntdob();
		Date date = null;
		try {
			date = formatter.parse(dateInString1);
		} catch (ParseException e) {
			   e.printStackTrace();
		}
		SimpleDateFormat formatter1 = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);

		String dateInString2 =loanreqDTO.getGntrdob();
		Date gdate = null;
		try {
			gdate = formatter1.parse(dateInString2);
		} catch (ParseException e) {
			   e.printStackTrace();
		}
		applicantDAO.setAplcntAdharNumber(loanreqDTO.getAplcntAdharNumber());
		applicantDAO.setAplcntName(loanreqDTO.getAplcntName());
		applicantDAO.setAplcntphNumber(loanreqDTO.getAplcntphNumber());
		applicantDAO.setAplcntgender(loanreqDTO.getAplcntgender());
		applicantDAO.setFatherName(loanreqDTO.getFatherName());
		applicantDAO.setMotherName(loanreqDTO.getMotherName());
		applicantDAO.setAplcntdob(date);
		applicantDAO.setAnnualIncome(loanreqDTO.getAnnualIncome());
		applicantDAO.setGntrAdharNumber(loanreqDTO.getGntrAdharNumber());
		applicantDAO.setGntrgender(loanreqDTO.getGntrgender());
		applicantDAO.setGntrdob(gdate);
		applicantDAO.setGntrName(loanreqDTO.getGntrName());
		applicantDAO.setGntrPhNumber(loanreqDTO.getGntrPhNumber());
		applicantDAO.setOccupation(loanreqDTO.getOccupation());
		applicantDAO.setEducationaldao(educationaldetaildao);
		
		applicantinfo.save(applicantDAO);
		
		List<ApplicantInfoDAO> list = applicantinfo.getAllApplicantInfo();
		
		list.stream().forEach(AllApplicantInfo->System.out.println(AllApplicantInfo));
		
		return "ApplicationInfo Inserted Successfully";
	}
	//@Transactional
	public String saveEduacationalDetails(LoanManagementRequestDTO loanreqDTO) {
		educationaldetaildao=new EducationalDetailsDAO();
		educationaldetaildao.setAplcntAdharNumber(loanreqDTO.getAplcntAdharNumber());
		educationaldetaildao.setCourseEndDate(loanreqDTO.getCourseEndDate());
		educationaldetaildao.setCourseStartDate(loanreqDTO.getCourseStartDate());
		educationaldetaildao.setPercentage(loanreqDTO.getPercentage());
		educationaldetaildao.setQualification(loanreqDTO.getQualification());
		educationaldetaildao.setUniversity(loanreqDTO.getUniversity());
		
		educationaldetailrepo.save(educationaldetaildao);
		
		return "Educational Details Inserted Successfully";
	}
}