package com.loan.mangement.service;

import com.loan.mangement.dto.LoanManagementRequestDTO;

public interface IApplicantsService {
	String saveApplicantInfo(LoanManagementRequestDTO loanreqDTO);
	
	
}
